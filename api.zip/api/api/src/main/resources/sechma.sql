CREATE TABLE IF NOT EXISTS Student (
fullName varchar(255),
phoneNum varchar(15),
emailAdd varchar (255),
birthDay varchar (255),
homeAddress varchar(255)
);